package gre.lab1.gui.impl;

public final class CanceledAnimationException extends RuntimeException {}
